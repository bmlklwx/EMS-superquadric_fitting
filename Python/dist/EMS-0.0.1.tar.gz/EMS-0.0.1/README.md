# EMS-probabilistic_superquadric_fitting
A probabilistic method to recover superquadrics from point clouds.
